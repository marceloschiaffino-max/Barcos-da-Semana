# Barcos da Semana

Site simples para montar a escala semanal dos barcos de remo. Não há login: qualquer pessoa com o link pode visualizar, editar e salvar.

## O que já está incluído

- Terça a sexta, às 6h30 e 7h30
- 4x (4 lugares), 2x (2), dois skiffs e Caravela (BB/BE/BB/BE)
- Salvamento automático
- Atualização em tempo real entre navegadores
- Navegação por semana
- Bloqueio de nome duplicado no mesmo horário
- Copiar semana anterior
- Limpar semana
- Gerar mensagem pronta para WhatsApp
- Layout para celular e computador

# Publicação passo a passo

## 1. Criar o banco no Supabase

1. Entre em https://supabase.com e crie uma conta gratuita.
2. Clique em **New project**.
3. Dê um nome ao projeto, escolha uma senha forte para o banco e selecione uma região próxima.
4. Quando o projeto estiver pronto, abra **SQL Editor**.
5. Clique em **New query**.
6. Copie todo o conteúdo de `supabase/setup.sql`, cole no editor e clique em **Run**.
7. Abra o painel **Connect** do projeto e copie:
   - **Project URL**
   - **Publishable key** (em projetos mais antigos pode aparecer como `anon public`)

Observação: o SQL libera leitura e escrita sem login de propósito. Qualquer pessoa que tenha o link poderá alterar os dados.

## 2. Testar no seu computador (opcional)

Você precisa ter o Node.js instalado.

1. Duplique `.env.example` e renomeie a cópia para `.env.local`.
2. Preencha:

```env
VITE_SUPABASE_URL=https://SEU-PROJETO.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=SUA_CHAVE_PUBLICAVEL
```

3. No terminal, dentro da pasta do projeto:

```bash
npm install
npm run dev
```

4. Abra o endereço mostrado no terminal, normalmente `http://localhost:5173`.

## 3. Colocar o código no GitHub

1. Crie uma conta em https://github.com, caso ainda não tenha.
2. Clique em **New repository**.
3. Nome sugerido: `barcos-da-semana`.
4. Deixe o repositório como **Private** ou **Public**.
5. Faça upload de todos os arquivos desta pasta. O GitHub permite usar **Add file → Upload files**.
6. Confirme em **Commit changes**.

Não envie o arquivo `.env.local` ao GitHub.

## 4. Publicar na Vercel

1. Entre em https://vercel.com usando a conta do GitHub.
2. Clique em **Add New → Project**.
3. Selecione o repositório `barcos-da-semana`.
4. A Vercel detectará automaticamente que é um projeto Vite.
5. Antes de clicar em **Deploy**, abra **Environment Variables** e crie:

| Nome | Valor |
|---|---|
| `VITE_SUPABASE_URL` | Project URL do Supabase |
| `VITE_SUPABASE_PUBLISHABLE_KEY` | Publishable key do Supabase |

6. Clique em **Deploy**.
7. Ao terminar, a Vercel fornecerá um endereço semelhante a:

```text
https://barcos-da-semana.vercel.app
```

Esse é o link que você pode enviar aos atletas.

## 5. Alterar o endereço gratuito (opcional)

Dentro do projeto na Vercel:

1. Vá a **Settings → Domains**.
2. Edite o domínio `.vercel.app`, caso o nome escolhido esteja disponível.

Não é necessário comprar domínio.

# Manutenção

Para alterar barcos, horários ou dias, edite as constantes `DAYS`, `TIMES` e `BOATS` no início de `src/main.jsx`.

Após editar e enviar a mudança ao GitHub, a Vercel publica automaticamente uma nova versão.

# Aviso importante sobre acesso sem login

O modelo sem login é simples e conveniente, mas qualquer pessoa com o endereço poderá:

- trocar nomes;
- apagar campos;
- limpar a semana.

O site pede confirmação antes de apagar toda a semana. Para um grupo fechado, compartilhe o link apenas no WhatsApp do remo.
